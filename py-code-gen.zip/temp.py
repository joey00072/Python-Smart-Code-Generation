import torch
import torch.nn as nn

model = nn.Sequential(
    nn.Linear(2,2),
)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu') 


print(model.state_dict())

model.to(device)

print(model.cpu().state_dict())
print(model.state_dict())