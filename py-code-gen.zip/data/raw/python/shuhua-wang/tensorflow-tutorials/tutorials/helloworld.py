from __future__ import print_function

import os
import tensorflow as tf

# 0 = all messages are logged (default behavior)
# 1 = INFO messages are not printed
# 2 = INFO and WARNING messages are not printed
# 3 = INFO, WARNING, and ERROR messages are not printed
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '1'


def main():
    # Create a Tensor
    hello = tf.constant('Hello, TensorFLow!')
    print(hello)

    # To access a Tensor value, call numpy()
    print(hello.numpy())


if __name__=="__main__":
    main()
